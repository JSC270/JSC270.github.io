login = "yourname@utoronto.ca"
pwd = "yourpassword"